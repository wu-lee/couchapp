(function(acralyzerConfig, undefined ) {
    "use strict";
    // Update this variable with the name of your app:
    acralyzerConfig.defaultApp = "storage";
    acralyzerConfig.backgroundPollingOnStartup = true;

    acralyzerConfig.appDBPrefix = "acra-";

    // Helper functions

}( window.acralyzerConfig = window.acralyzerConfig || {} ));
